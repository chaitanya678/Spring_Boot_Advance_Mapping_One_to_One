package com.luv2code.crud.demo.demo.DAO;

import com.luv2code.crud.demo.demo.entity.Instructor;
import org.springframework.stereotype.Repository;


public interface AppDao {

    void save(Instructor theinstructor);

    Instructor findInstructorById(int theId);

    void deleteById( int theId);

}
