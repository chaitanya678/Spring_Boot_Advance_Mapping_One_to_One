package com.luv2code.crud.demo.demo;

import com.luv2code.crud.demo.demo.DAO.AppDao;
import com.luv2code.crud.demo.demo.entity.Instructor;
import com.luv2code.crud.demo.demo.entity.InstructorDetail;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}
		@Bean
		public CommandLineRunner commandLineRunner(AppDao appDao){

		return runner ->{

			//createInstructor(appDao);

			//findInstructor(appDao);

			deleteInstructor(appDao);

		};


		}

	private void deleteInstructor(AppDao appDao) {
		int theId = 1;
		System.out.println("Deleting Insturtor of Id"+ theId);

		appDao.deleteById(theId);
	}

	private void findInstructor(AppDao appDao) {

		int theId = 1;
		System.out.println("Finding Instructor id " + theId);


		Instructor tempInstructor = new Instructor();
		tempInstructor = appDao.findInstructorById(theId);

		System.out.println(tempInstructor);
	}

	private void createInstructor(AppDao appDao) {

		Instructor tempinstructor = new Instructor("ram", "das", "ram@gmail.com");


		InstructorDetail tempinstructordetail = new InstructorDetail("decoding", "gaming");

		tempinstructor.setInstructorDetail(tempinstructordetail);
		System.out.println("Saving Instrcutor: " + tempinstructor);
		appDao.save(tempinstructor);

	}

	}

